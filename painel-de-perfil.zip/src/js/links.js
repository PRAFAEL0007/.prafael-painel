// SOCIALS

const steam = () => (window.open(""));
const instagram = () => (window.open("https://www.instagram.com/_eurafael.ofc/"));
const github = () => (window.open("https://github.com/PRAFAEL0007?tab=repositories"));
const spotify = () => (window.open("https://spotify.link/fPkBaRWlbDb"));
const pinterest = () => (window.open(""));

// OTHERS

const arch = () => (window.open("https://discord.gg/schemaposse"));
const biel = () => (window.open("https://discord.gg/schemaposse"));
